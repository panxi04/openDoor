package com.rocoplayer.app;


/**
 * 打包可以直接使用App.java
 * 开发工具中main方法运行此类
 * @author ZJ
 *
 */
public class Launcher {

    public static void main(String[] args) {
        App.main(args);
    }

}

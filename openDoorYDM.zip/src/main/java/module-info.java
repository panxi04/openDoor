module com.rocoplayer {
	
	requires java.desktop;
    requires com.formdev.flatlaf;
    


    exports com.rocoplayer.app;
}

